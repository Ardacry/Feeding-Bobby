package com.bilkent.feedingbobby.model;

public abstract class SpecialFish extends Fish{

}
