package com.bilkent.feedingbobby.model;

public enum GraphicsQuality {

    LOW, NORMAL, HIGH

}
