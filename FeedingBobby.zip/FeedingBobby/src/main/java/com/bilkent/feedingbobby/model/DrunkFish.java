package com.bilkent.feedingbobby.model;

import com.bilkent.feedingbobby.controller.GameManager;
import com.bilkent.feedingbobby.controller.GameMapManager;

public class DrunkFish extends SpecialFish{

	@Override
	public void move() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateState(GameManager gameManager, GameMapManager gameMapManager, PlayerFish playerFish) {
		// TODO Auto-generated method stub
		
	}

}
