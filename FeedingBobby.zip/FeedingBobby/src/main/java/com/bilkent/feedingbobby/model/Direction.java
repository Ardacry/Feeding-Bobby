package com.bilkent.feedingbobby.model;

public enum Direction {

    LEFT, RIGHT, UP, DOWN
}
